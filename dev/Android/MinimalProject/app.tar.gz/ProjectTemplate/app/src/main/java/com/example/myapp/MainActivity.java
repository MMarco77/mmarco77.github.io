package com.example.myapp;

import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;

import java.lang.reflect.Method;

import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import android.widget.TextView;

public class MainActivity extends Activity {
    public final static String TAG = "APP_AG";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.i(TAG, "MainActivty called!");
        super.onCreate(savedInstanceState);
        TextView textView = new TextView(this);

        String text = getResources().getString(R.string.welcomeText);
        textView.setText(text);

        setContentView(textView);
    }
}